a) Reused Code:
For stage four, I used the timer library provided by class CSCI 551 at USC. 

b) Complete:
Yes, I complete this stage.

c) Reliability:
I use the class timer library.

d) Chance of Failure:
If one udp message and a control message reach to the router at the same time, the control message may be lost.
It is unlikely to happen if the network is not very busy.


