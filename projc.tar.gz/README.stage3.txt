a) Reused Code:
For stage three, I didn't use code from anywhere. 

b) Complete:
Yes, I complete this stage.

c) Addressing on the way out of your router: 
If don't do so, the reply message will bypass the second router and arrive at tun directly.

d) Addressing on the way in to the VM: 
To let different routers deal with different kind of flow seperately.

e) Addressing from the VM to the host: 
NAT



