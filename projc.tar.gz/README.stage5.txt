a) Reused Code:
For stage five, I didn't use code from anywhere. 

b) Complete:
Yes, I complete this stage.

c)  Authentication:
Some people may capture the control message through their own switch, then hack the message and send their own messages which can destroy the whole network.
