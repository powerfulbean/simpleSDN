a) Reused Code:
For stage six, I didn't use code from anywhere.  

b) Complete:
Yes, I complete this stage.

c) Multiplexing: 
Based on the different destination addresses of those traffic, packets will be sent to the router binded with the destination address. 

