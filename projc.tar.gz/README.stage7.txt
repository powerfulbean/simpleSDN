a) Reused Code:
For stage seven, I didn't use code from anywhere. 

b) Complete:
Yes, I complete this stage.

c) Diversion with normal routers:
It is not easy to manage the whole network. It is not centralized control, so people have to login to all the routers and check or modify the router table.

