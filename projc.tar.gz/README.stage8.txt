a) Reused Code:
For stage eight, I didn't use code from anywhere. 

b) Complete:
Yes, I complete this stage.

c) Diversion of HTTP and HTTPS: 
Because the web browsing will not diverse the output traffic to proxy.

d) Diversion of HTTP and HTTPS, take 2:
We can set manual proxy conﬁguration to use certain proxy for all https traffic in the network settings of the browser.

