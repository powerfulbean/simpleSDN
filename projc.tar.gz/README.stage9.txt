a) Reused Code:
For stage nine, I didn't use code from anywhere. 

b) Complete:
Yes, I complete this stage.

c) Security/privacy: 
The information contained in GET is encrypted in HTTPS, so we need implement a program to unencrypt it.

d) Security/authentication: 
By tracking its port and IP address.

e) Insecurity/authentication: 
People can hack their output traffic, and use another ports and IP addresses binded to other users. 


